> <img src="./4da0dwmx.png"
> style="width:14.75601in;height:9.8333in" />*Object-Oriented*
> *Programming*

PROJECT **SKYPE** *Kevin* *Navarrete*

*Valeria* *Usma*

> <img src="./rdhfgw05.png"
> style="width:12.68669in;height:8.45779in" />CONTENT
>
> <img src="./j4iplqir.png"
> style="width:0.9158in;height:1.32205in" /><img src="./itd2hlol.png"
> style="width:2.92708in;height:14.8125in" /><img src="./zuegab33.png"
> style="width:7.51475in;height:11.24963in" /><img src="./5n3y0hwk.png"
> style="width:2.92708in;height:14.8125in" /><img src="./q455blhz.png"
> style="width:0.60677in;height:0.5026in" /><img src="./0t2qyz0n.png"
> style="width:1.43576in;height:0.80122in" /><img src="./hz3ewv5i.png"
> style="width:0.81337in;height:0.81337in" /><img src="./c25vqddb.png"
> style="width:1.61428in;height:0.49679in" />OBJECTIVES

Make an app where the users can send and receive messages, make voice
and video calls and share

activities with their partners.

Implement a system or an authenticator where every user can have a
personal

> account.

Design a website that is easy to use for everyone functionalities and a
sea experience that enhanc

responsiveness, and use

> USER STORIES

<img src="./lr0kbx4n.png"
style="width:2.65799in;height:1.11979in" /><img src="./1ncco2yv.png"
style="width:2.65799in;height:1.11979in" /><img src="./teufun1l.png"
style="width:3.109in;height:1.11979in" /><img src="./w0wjeybt.png"
style="width:2.65799in;height:1.11979in" /><img src="./radmesav.png"
style="width:2.65799in;height:1.11979in" /><img src="./jkxoamme.png"
style="width:3.109in;height:1.11979in" />

<img src="./f1nawfqd.png"
style="width:2.65799in;height:1.11979in" /><img src="./0k4tceba.png"
style="width:2.65799in;height:1.11979in" /><img src="./zyr4frdy.png"
style="width:3.109in;height:1.11979in" /><img src="./p1vhn5eq.png"
style="width:2.65799in;height:1.11979in" /><img src="./drpalgga.png"
style="width:2.65799in;height:1.11979in" /><img src="./01bf2b2m.png"
style="width:3.109in;height:1.11979in" />

<img src="./ou0fag5r.png"
style="width:2.65799in;height:1.11979in" /><img src="./pgq5opgi.png"
style="width:2.65799in;height:1.11979in" /><img src="./e5vg1xsn.png"
style="width:3.109in;height:1.11979in" /><img src="./prq30d4v.png"
style="width:2.65799in;height:1.11979in" /><img src="./aefu24mo.png"
style="width:2.65799in;height:1.11979in" /><img src="./y1rh4z5i.png"
style="width:3.109in;height:1.11979in" />

<img src="./jsnbtghz.png"
style="width:2.65799in;height:1.11979in" /><img src="./f05flee0.png"
style="width:2.65799in;height:1.11979in" /><img src="./thtt4ayd.png"
style="width:3.109in;height:1.11979in" /><img src="./3wzwpouq.png"
style="width:2.65799in;height:1.11979in" /><img src="./tmxqclwl.png"
style="width:2.65799in;height:1.11979in" /><img src="./muxgqrfk.png"
style="width:3.109in;height:1.11979in" />

<img src="./h3xcglko.png"
style="width:2.65799in;height:1.11979in" /><img src="./chhjebb4.png"
style="width:2.65799in;height:1.11979in" /><img src="./ylsvorxp.png"
style="width:3.109in;height:1.11979in" /><img src="./0j5jod1y.png"
style="width:2.65799in;height:1.11979in" /><img src="./3w5dhezk.png"
style="width:2.65799in;height:1.11979in" /><img src="./0svcc5gj.png"
style="width:3.109in;height:1.11979in" />

> MOCK-UPS
>
> <img src="./ws32a1mb.png"
> style="width:12.80208in;height:7.19792in" />**Sign-In**
>
> <img src="./4n52m3kp.png"
> style="width:12.46875in;height:7.0625in" />**PrincipalPage**
>
> <img src="./i2vmfr3i.png"
> style="width:12.86458in;height:7.28125in" />**Profile**
>
> CRC CARDS

||
||
||
||

||
||
||
||

||
||
||
||

||
||
||
||

||
||
||
||

||
||
||
||
